#-----Statement of Authorship----------------------------------------#
#
#  This is an individual assessment item for QUT's teaching unit
#  ITD104, "Building IT Systems", C1, 2023.  By submitting
#  this code I agree that it represents my own work.  I am aware of
#  the University rule that a student must not act in a manner
#  which constitutes academic dishonesty as stated and explained
#  in QUT's Manual of Policies and Procedures, Section C/5.3
#  "Academic Integrity" and Section E/2.1 "Student Code of Conduct".
#
student_number =  11479752 # put your student number here as an integer
student_name   =  "Ngoc Anh Duong Nguyen" # put your name here as a character string
#
#  NB: Files submitted without a completed copy of this statement
#  will not be marked.  All files submitted will be subjected to
#  software plagiarism analysis using the MoSS system
#  (http://theory.stanford.edu/~aiken/moss/).
#
#--------------------------------------------------------------------#



#-----Assignment Description-----------------------------------------#
#
#  What's NEWs
#
#  In this assignment you will combine your knowledge of HTMl/CSS
#  mark-up languages with your skills in Python scripting, pattern
#  matching, databases and Graphical User Interface design to produce
#  a useful application that allows the user to compare news stories
#  from multiple sources and save them for later perusal.
#
#  See the client's requirements accompanying this file for full
#  details.
#
#--------------------------------------------------------------------#
 


#-----Initialisation Steps-------------------------------------------#
#

# Import standard Python 3 modules needed to complete this assignment.
# [No other modules are needed for your solution.
# Your solution MUST NOT rely on any other modules.]
#
# A function for exiting the program immediately (renamed
# because "exit" is already a standard Python function).
from sys import exit as abort

# The function for opening a web document given its URL.
# (You WILL need to use this function in your solution,
# either directly or via our "download" function below.)
from urllib.request import urlopen

# Some standard Tkinter functions.  (You WILL need to use
# SOME of these functions in your solution.)  You may also
# import other widgets from the "tkinter" module, provided they
# are standard ones and don't need to be downloaded and installed
# separately.  (NB: DON'T import all of the "tkinter.tkk" functions
# using a "*" wildcard because this module includes alternative
# versions of standard widgets like "Label".)
from tkinter import *
from tkinter.scrolledtext import ScrolledText
from tkinter.ttk import Progressbar

# Functions for finding occurrences of a pattern defined
# via a regular expression.  (You do not necessarily need to
# use these functions in your solution, because the problem
# can be solved with the string "find" function, but it will
# be difficult to produce a concise and robust solution
# without using regular expressions.)
from re import *

# A function for displaying a web document in the host
# operating system's default web browser (renamed to
# distinguish it from the built-in "open" function for
# opening local files).  (You WILL need to use this function
# in your solution.)
from webbrowser import open as urldisplay

# Import the date and time function.
# This module *may* be useful, depending on the websites you choose.
# Eg convert from a timestamp to a human-readable date:
# >>> datetime.fromtimestamp(1586999803) # number of seconds since 1970
# datetime.datetime(2020, 4, 16, 11, 16, 43)
from datetime import datetime

# Confirm that the student has declared their authorship.
# You must NOT change any of the code below.
if not isinstance(student_number, int):
    print('\nUnable to run: No student number supplied',
          '(must be an integer)\n')
    abort()
if not isinstance(student_name, str):
    print('\nUnable to run: No student name supplied',
          '(must be a character string)\n')
    abort()

#
#--------------------------------------------------------------------#



#-----Supplied Function----------------------------------------------#
#
# Below is a function you can use in your solution if you find it
# helpful.  (You are not required to use this function, but it may
# save you some effort.)
#
# A function to download and save a web document.  The function
# returns the downloaded document as a character string and
# optionally saves it as a local file.  If the attempted download
# fails, an error message is written to the shell window and the
# special value None is returned.
#
# Parameters:
# * url - The address of the web page you want to download.
# * target_filename - Name of the file to be saved (if any).
# * filename_extension - Extension for the target file, usually
#      "html" for an HTML document or "xhtml" for an XML
#      document.
# * save_file - A file is saved only if this is True. WARNING:
#      The function will silently overwrite the target file
#      if it already exists!
# * char_set - The character set used by the web page, which is
#      usually Unicode UTF-8, although some web pages use other
#      character sets.
def download(url = 'http://www.wikipedia.org/',
             target_filename = 'downloaded_document',
             filename_extension = 'html',
             save_file = True,
             char_set = 'UTF-8'):

    # Import the function for opening online documents and
    # the class for creating requests
    from urllib.request import urlopen, Request

    # Import an exception raised when a web server denies access
    # to a document
    from urllib.error import HTTPError

    # Open the web document for reading
    try:
        request = url
        web_page = urlopen(request)
    except ValueError:
        print("Download error - Cannot find document at URL '" + url + "'\n")
        return None
    except HTTPError:
        print("Download error - Access denied to document at URL '" + url + "'\n")
        return None
    except Exception as message:
        print("Download error - Something went wrong when trying to download " + \
              "the document at URL '" + url + "'")
        print("Error message was:", message, "\n")
        return None

    # Read the contents as a character string
    try:
        web_page_contents = web_page.read().decode(char_set)
    except UnicodeDecodeError:
        print("Download error - Unable to decode document from URL '" + \
              url + "' as '" + char_set + "' characters\n")
        return None
    except Exception as message:
        print("Download error - Something went wrong when trying to decode " + \
              "the document from URL '" + url + "'")
        print("Error message was:", message, "\n")
        return None

    # Optionally write the contents to a local text file
    # (overwriting the file if it already exists!)
    if save_file:
        try:
            text_file = open(target_filename + '.' + filename_extension,
                             'w', encoding = char_set)
            text_file.write(web_page_contents)
            text_file.close()
        except Exception as message:
            print("Download error - Unable to write to file '" + \
                  target_filename + "'")
            print("Error message was:", message, "\n")

    # Return the downloaded document to the caller
    return web_page_contents

#
#--------------------------------------------------------------------#



#-----Student's Solution---------------------------------------------#

# Configure the window
news_window = Tk()
news_window.geometry("920x750")
news_window.title("Formula 1: Lights Out News")
background_colour = "#ADD8E6"
news_window.configure(background = background_colour)
page_font = ("Arial", 18)

# Determine the RSS feeds to use from the websites
autosports_feed = "https://www.autosport.com/rss/f1/news/"
guardian_feed = "https://www.theguardian.com/sport/formulaone/rss"

# Error message for other errors
other_error_message = f"Something went wrong: {error}"

# Track the selected option in the news options frame
selected_source = StringVar()

# Open the live RSS website of the selected source
def open_website():

    # Get the selected news source
    news_source = selected_source.get()
    if news_source == "Autosports":
        urldisplay(autosports_feed)
    elif news_source == "The Guardian":
        urldisplay(guardian_feed)

# Donwload the RSS feed of the chosen news source
def download_rss_feed():
    news_source = selected_source.get()
    if news_source == "Autosports":
        download(url = autosports_feed,
             target_filename = "autosports_rss_feed",
             filename_extension = "xhtml",
             save_file = True,
             char_set = "UTF-8")
    elif news_source == "The Guardian":
        download(url = guardian_feed,
             target_filename = "guardian_rss_feed",
             filename_extension = "xhtml",
             save_file = True,
             char_set = "UTF-8")

    # Enable Quick Snapshot button once a news source is selected
    snapshot_button.configure(state = "normal")

    # Display intermission message in snapshot after news source is selected
    news_snapshot.delete("1.0", END)
    news_snapshot.insert("1.0", "Waiting to display the snapshot...")
 
    view_website_button.configure(state = "normal")

    # Disable Output Summary button when other source is selected
    summary_button.configure(state = "disabled")

# Extract the news stories from autosports's RSS feed
def extract_autosports_news(feed_filename):
    try: 
        # Read and decode the RSS feed
        with open(feed_filename, "r",
                  encoding="ascii",
                  errors="ignore") as file:
            feed_content = file.read()

        # Regex patterns to scrape the desired news content
        item_pattern = r'<item>(.*?)</item>'
        title_pattern = r'<title>\s*<!\[CDATA\[(.*?)\]\]>\s*</title>'
        image_pattern = r'<enclosure url="(.*?)"'
        summary_pattern = r'<description>\s*<!\[CDATA\[(?!<br>)(.*?)\]\]>\s*</description>'
        date_pattern = r'<pubDate>(.*?)</pubDate>'

        items = findall(item_pattern, feed_content, flags=DOTALL)

        # Store the scraped content in a list
        top_news = []
        for item in items:
            title = findall(title_pattern, item, flags=DOTALL)[0]
            image = findall(image_pattern, item, flags=DOTALL)[0]
            summary = findall(summary_pattern, item, flags=DOTALL)[0]
            date = findall(date_pattern, item, flags=DOTALL)[0]

            if summary:

                # Remove unecessary characters
                summary = sub(r"<br>|Keep reading", " ", summary)

                top_news.append((title, image, summary, date))

        # Return the top 10 news stories
        return top_news[:10]

    # Exception when RSS feed can't be found 
    except FileNotFoundError:

        # Update text box when snapshot can't be displayed
        news_snapshot.delete("1.0", END)
        news_snapshot.insert(END, "Autosport's snapshot can't be displayed.")
        
    except Exception as error:
        print(other_error_message)

# Extract the news stories from The Guardian's RSS feed
def extract_guardian_news(feed_filename):
    try:
        # Read and decode the RSS feed
        with open(feed_filename, "r",
                  encoding = "ascii",
                  errors = "ignore") as file:
            feed_content = file.read()

        # Regex patterns to scrape the desired news content
        item_pattern = r'<item>(.*?)</item>'
        title_pattern = r'<title>(.*?)</title>'
        summary_pattern = r'<description>(.*?)</description>'
        date_pattern = r'<pubDate>(.*?)</pubDate>'
        image_pattern = r'<media:content width="460" url="(.*?)"'

        items = findall(item_pattern, feed_content, flags = DOTALL)

        # Store the scraped content in a list
        top_news = []
        for item in items:
            title = findall(title_pattern, item, flags = DOTALL)[0]
            if "The Guardian" in title:
                continue
            summary = findall(summary_pattern, item, flags = DOTALL)[0]
            date = findall(date_pattern, item, flags = DOTALL)[0]
            image = findall(image_pattern, item, flags = DOTALL)[0]

            # Remove uneccessary characters
            summary = sub(r"<.*?>|&lt;.*?&gt;|Continue reading...",
                          " ", summary)

            top_news.append((title, image, summary, date))

        # Return the top 10 news stories
        return top_news[:10]

    # Exception when RSS feed can't be found
    except FileNotFoundError:

        # Update text box when snapshot can't be displayed
        news_snapshot.delete("1.0", END)
        news_snapshot.insert(END, "The Guardian's snapshot can't be displayed.")
        
    except Exception as error:
        print(other_error_message)

# Update the news snapshot textbox with the top 5 news stories
def update_news_snapshot():
    try: 
        # Enable Output Summary button
        summary_button.configure(state = "normal")

        # Clear the existing content in the snapshot
        news_snapshot.delete("1.0", END)

        # Get the selected news source
        news_source = selected_source.get()
        if news_source == "Autosports":
            top_news = extract_autosports_news("autosports_rss_feed.xhtml")
        elif news_source == "The Guardian":
            top_news = extract_guardian_news("guardian_rss_feed.xhtml")

        # Display the top 5 news stories in the textbox
        for item, (title,
                image,
                summary,
                pub_date) in enumerate (top_news[:5], start = 1):
            news_snapshot.insert(END, f"Title: {title}\n\n")
            news_snapshot.insert(END, f"Date/Time: {pub_date}\n")
            news_snapshot.insert(END, "-" * 50 + "\n")
            
    # Exception for when no scraping has been done to display snapshot
    except TypeError:
        print("Error: Unable to display snapshot.")
        
    except Exception as error:
        print(other_error_message)

# Create the HTML file for the news summary
def generate_html_summary(news_list, file_name, feed_link, source_logo):
        html_content = '''<DOCTYPE html>
                            <html>
                                <head>
                                    <title> Formula 1 News Summary </title>
                                        <style>
                                            body {font-family: Arial, sans-serif;}
                                            h1 {text-align: center; font-size: 50px;}
                                            h2 {text-align: center; font-size: 25px;}
                                            h3 {text-align: center; font-size: 20px; margin-top: 10px;}
                                            img {display: block; margin: 0 auto; max-width: 460px;}
                                        </style>
                                    </head>
                                    <body bgcolor = "#ADD8E6">
                                    <h1> Formula1 News </h1>'''
       
        # Display the logo of the news source and RSS feed link
        html_content += f"<img src='{source_logo}' alt='News Source Logo'>\n"
        html_content += f"<h3> RSS Feed: <a href='{feed_link}'>{feed_link}</a></h3>\n"

        # Display the latest ten news articles
        for item, news in enumerate(news_list, start = 1):
            title, image, summary, pub_date = news
            html_content += f"<h2>{item}. {title}</h2>\n"  
            html_content += f"<img src='{image}' alt='Image'>\n"
            html_content += f"<p>{summary}</p>\n"
            html_content += f"<p><strong>Date/Time:</strong> {pub_date}</p>\n"
            html_content += "<hr>\n"

        html_content += '''</body>
                                </html>'''
        
        # Write and save the HTML file
        with open(file_name, "w+") as file:
            file.write(html_content)

# Generate the HTML then open it when output summary button is pressed
def open_output_summary():

    try:
        # Determine the news source selected
        news_source = selected_source.get()
        if news_source == "Autosports":
            news_list = extract_autosports_news("autosports_rss_feed.xhtml")
            feed_link = autosports_feed
            source_logo = "autosports_logo.png"  
        elif news_source == "The Guardian":
            news_list = extract_guardian_news("guardian_rss_feed.xhtml")
            feed_link = guardian_feed
            source_logo = "guardian_logo.png"
        
       # Generate the HTML file and open it in the default browser
        file_name = "news_summary.html"  
        generate_html_summary(news_list, file_name, feed_link, source_logo)
        urldisplay(file_name)

    # Exception for when no scraping has been done to generate summary
    except TypeError:
        print("Error: Unable to open news summary.")
        
    except Exception as error:
        print(other_error_message)

# Display the window header
heading = Label(news_window,
                text = "Formula1 News",
                font = ("Arial Black", 50),
                foreground = "#333",
                background = background_colour)

heading.grid(column = 1,
             row = 1,
             pady = (10, 10),
             padx = 10)

# Image taken from Mercedes-AMG PETRONAS F1 Team twitter
f1_image = PhotoImage(file = "104 f1 image.png")

# Label to display the F1 image
photo_label = Label(news_window,
                    image = f1_image)

photo_label.grid(column = 1,
                 row = 2,
                 padx = 10)

# Create a frame to hold the news feed options button
news_options_frame = LabelFrame(news_window,
                               relief = "groove",
                               text = "News Source",
                               font = page_font,
                               borderwidth = 2,
                               background = background_colour)

# Create two radio buttons within the news feeds frame
autosports_button = Radiobutton(news_options_frame,
                                text = "Autosports",
                                font = page_font,
                                background = background_colour,
                                command = download_rss_feed,
                                variable = selected_source,
                                value = "Autosports")

Guardian_button = Radiobutton(news_options_frame,
                              text = "The Guardian",
                              font = page_font,
                              background = background_colour,
                              command = download_rss_feed,
                              variable = selected_source,
                              value = "The Guardian")

# Grid the news source options radio buttons in the frame
autosports_button.grid(row = 1,
                       pady = (10, 0),
                       padx = 20,
                       sticky = "w")

Guardian_button.grid(row = 2,
                     columnspan = 2,
                     padx= 20,
                     sticky = "w")

# Frame to hold the display options buttons
display_options_frame = LabelFrame(news_window,
                                   relief = "groove",
                                   text = "Display Options",
                                   font = page_font,
                                   borderwidth = 2,
                                   background = background_colour)

# Button to display the snapshot
snapshot_button = Button(display_options_frame,
                         text = "Quick Snapshot",
                         font = page_font,
                         background = background_colour,
                         command = update_news_snapshot)

# Button to output the news summary
summary_button = Button(display_options_frame,
                        text = "Output Summary",
                        font = page_font,
                        background = background_colour,
                        command = open_output_summary)

# Grid the display options buttons into the frame
snapshot_button.grid(row = 1,
                     pady = (10, 0),
                     padx = 20,
                     sticky = "w")

summary_button.grid(row = 2,
                    padx = 20,
                    sticky = "w")

# Grid the label widgets into the window
news_options_frame.grid(column = 2,
                       row = 1,
                       pady = 20,
                       padx = 150,
                       sticky = "w")

display_options_frame.grid(column = 1,
                           row = 3,
                           padx = 30,
                           sticky = "n")

# Button to view the live website
view_website_button = Button(news_window,
                             text = "Open Live Website",
                             font = page_font,
                             command = open_website)

view_website_button.grid(column = 2,
                         row = 3,
                         pady = 5,
                         padx = 120,
                         sticky = "w")

# Label to hold the news snapshot textbox
news_snapshot_label = LabelFrame(news_window,
                                 text = "News Snapshot",
                                 font = page_font,
                                 background = background_colour)

news_snapshot_label.grid(column = 2,
                         row = 2,
                         pady = (5, 5),
                         padx = 10)

# Display the news snapshot textbox
news_snapshot = ScrolledText(news_snapshot_label,
                             width = 40,
                             height = 20,
                             font = ("Arial", 15),
                             wrap = WORD)

news_snapshot.grid(column = 2,
                   row = 2,
                   pady = 5,
                   padx = 5)

# Disable all buttons other than the news sources by default
snapshot_button.configure(state = "disabled")
summary_button.configure(state = "disabled")
view_website_button.configure(state = "disabled")

# Add initial message to the news_snapshot textbox
initial_message = "Check out the summary of the latest 5 news stories."
news_snapshot.insert("1.0", initial_message)

news_window.mainloop()
